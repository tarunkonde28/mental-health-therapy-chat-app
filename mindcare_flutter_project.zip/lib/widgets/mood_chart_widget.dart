import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/mood_entry.dart';
import '../theme/app_theme.dart';

class MoodChartWidget extends StatelessWidget {
  final List<MoodEntry> entries;

  const MoodChartWidget({super.key, required this.entries});

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return Container(
        height: 160,
        alignment: Alignment.center,
        child: const Text('Log moods to see your weekly trend.', style: TextStyle(color: AppTheme.textMuted)),
      );
    }

    final spots = <FlSpot>[];
    final displayEntries = entries.take(7).toList().reversed.toList();
    for (int i = 0; i < displayEntries.length; i++) {
      spots.add(FlSpot(i.toDouble(), displayEntries[i].intensity.toDouble()));
    }

    return Container(
      height: 180,
      padding: const EdgeInsets.only(top: 16, right: 20, left: 10, bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.black.withOpacity(0.04)),
      ),
      child: LineChart(
        LineChartData(
          minY: 1,
          maxY: 5,
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            horizontalInterval: 1,
            getDrawingHorizontalLine: (value) => FlLine(
              color: Colors.black.withOpacity(0.04),
              strokeWidth: 1,
            ),
          ),
          titlesData: FlTitlesData(
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                interval: 1,
                reservedSize: 28,
                getTitlesWidget: (val, meta) {
                  String label = '';
                  if (val == 5) label = '😊';
                  if (val == 4) label = '😌';
                  if (val == 3) label = '😐';
                  if (val == 2) label = '😟';
                  if (val == 1) label = '😢';
                  return Text(label, style: const TextStyle(fontSize: 12));
                },
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (val, meta) {
                  return Text('D${val.toInt() + 1}', style: const TextStyle(fontSize: 10, color: AppTheme.textMuted));
                },
              ),
            ),
          ),
          borderData: FlBorderData(show: false),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              color: AppTheme.lavenderPrimary,
              barWidth: 3,
              isStrokeCapRound: true,
              dotData: const FlDotData(show: true),
              belowBarData: BarAreaData(
                show: true,
                color: AppTheme.lavenderPrimary.withOpacity(0.12),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
