import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class EmergencyHelpSheet extends StatelessWidget {
  const EmergencyHelpSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: const [
                Icon(Icons.health_and_safety_rounded, color: Color(0xFFC53030), size: 28),
                SizedBox(width: 10),
                Text(
                  'Immediate Support & Helplines',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'If you or someone you know is in immediate crisis, please reach out to qualified emergency support. MindCare is a self-care app and does not replace emergency medical care.',
              style: TextStyle(fontSize: 13, height: 1.4, color: AppTheme.textMuted),
            ),
            const SizedBox(height: 20),

            _buildContactRow(
              title: '988 Suicide & Crisis Lifeline',
              subtitle: 'Free, confidential, available 24/7 across USA & Canada',
              phone: 'Dial 988',
            ),
            const SizedBox(height: 12),
            _buildContactRow(
              title: 'Crisis Text Line',
              subtitle: 'Free 24/7 text support with trained crisis counselors',
              phone: 'Text HOME to 741741',
            ),
            const SizedBox(height: 12),
            _buildContactRow(
              title: 'Tele-MANAS & KIRAN Helpline',
              subtitle: 'Toll-free 24/7 national mental health helpline (India)',
              phone: '14416 / 1800-599-0019',
            ),
            const SizedBox(height: 20),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.textDark),
                child: const Text('Close'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactRow({
    required String title,
    required String subtitle,
    required String phone,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF5F5),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFEB2B2)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                const SizedBox(height: 2),
                Text(subtitle, style: const TextStyle(fontSize: 11.5, color: AppTheme.textMuted)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFFC53030),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              phone,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }
}
