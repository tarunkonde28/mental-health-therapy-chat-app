import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/mood_entry.dart';

class StorageService {
  static const String _moodKey = 'mindcare_mood_entries_v1';
  static const String _selfCareKey = 'mindcare_completed_tasks_v1';

  static Future<List<MoodEntry>> loadMoodEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString(_moodKey);
    if (jsonString == null || jsonString.isEmpty) {
      return _getDefaultEntries();
    }
    try {
      final List decoded = jsonDecode(jsonString);
      return decoded.map((item) => MoodEntry.fromJson(item)).toList();
    } catch (_) {
      return _getDefaultEntries();
    }
  }

  static Future<void> saveMoodEntries(List<MoodEntry> entries) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = jsonEncode(entries.map((e) => e.toJson()).toList());
    await prefs.setString(_moodKey, encoded);
  }

  static Future<void> clearAllMoodData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_moodKey);
  }

  static List<MoodEntry> _getDefaultEntries() {
    final now = DateTime.now();
    return [
      MoodEntry(
        id: '1',
        mood: 'calm',
        label: 'Calm & Grounded',
        intensity: 4,
        tags: ['Morning Walk', 'Tea'],
        notes: 'Had a restful morning without rushing.',
        timestamp: now.subtract(const Duration(days: 3)),
      ),
      MoodEntry(
        id: '2',
        mood: 'anxious',
        label: 'Anxious / Restless',
        intensity: 2,
        tags: ['College Deadline'],
        notes: 'Felt nervous regarding upcoming submission.',
        timestamp: now.subtract(const Duration(days: 2)),
      ),
      MoodEntry(
        id: '3',
        mood: 'okay',
        label: 'Okay / Neutral',
        intensity: 3,
        tags: ['Library Study'],
        notes: 'Steady progress made today.',
        timestamp: now.subtract(const Duration(days: 1)),
      ),
      MoodEntry(
        id: '4',
        mood: 'happy',
        label: 'Peaceful & Happy',
        intensity: 5,
        tags: ['Good Rest', 'Friends'],
        notes: 'Reconnected with classmates over coffee.',
        timestamp: now,
      ),
    ];
  }
}
