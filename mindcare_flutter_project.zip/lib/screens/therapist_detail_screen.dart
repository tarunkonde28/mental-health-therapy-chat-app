import 'package:flutter/material.dart';
import '../models/therapist.dart';
import '../theme/app_theme.dart';

class TherapistDetailScreen extends StatelessWidget {
  final Therapist therapist;

  const TherapistDetailScreen({super.key, required this.therapist});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Specialist Profile')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 46,
                    backgroundImage: NetworkImage(therapist.avatarUrl),
                    backgroundColor: AppTheme.lavenderLight,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    therapist.name,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    therapist.title,
                    style: const TextStyle(fontSize: 13, color: AppTheme.textMuted),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            const Text('About & Clinical Philosophy', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text(
              therapist.bio,
              style: const TextStyle(fontSize: 14, height: 1.5, color: AppTheme.textDark),
            ),
            const SizedBox(height: 20),
            const Text('Therapeutic Approaches', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: therapist.approaches
                  .map((appr) => Chip(
                        label: Text(appr, style: const TextStyle(fontSize: 12)),
                        backgroundColor: AppTheme.lavenderLight,
                      ))
                  .toList(),
            ),
            const SizedBox(height: 20),
            const Text('Credentials & Education', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(therapist.education, style: const TextStyle(fontSize: 13.5, color: AppTheme.textMuted)),
            const SizedBox(height: 36),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Demo: Session request sent to ${therapist.name}.')),
                  );
                },
                child: const Text('Book Demo Consultation'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
