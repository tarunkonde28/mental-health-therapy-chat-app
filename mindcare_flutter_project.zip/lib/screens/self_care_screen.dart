import 'package:flutter/material.dart';
import '../models/self_care_activity.dart';
import '../theme/app_theme.dart';

class SelfCareScreen extends StatefulWidget {
  const SelfCareScreen({super.key});

  @override
  State<SelfCareScreen> createState() => _SelfCareScreenState();
}

class _SelfCareScreenState extends State<SelfCareScreen> {
  final List<SelfCareActivity> _activities = [
    SelfCareActivity(
      id: '1',
      title: '3-Minute Mindful Breath',
      category: 'Mindfulness',
      durationMinutes: 3,
      isCompleted: true,
      description: 'Pause all screens and take 10 slow, diaphragmatic breaths.',
    ),
    SelfCareActivity(
      id: '2',
      title: 'Hydrate with Fresh Water',
      category: 'Body',
      durationMinutes: 1,
      isCompleted: true,
      description: 'Drink a full glass of cool water to support physical equilibrium.',
    ),
    SelfCareActivity(
      id: '3',
      title: '15-Minute Outdoor Walk',
      category: 'Body',
      durationMinutes: 15,
      isCompleted: false,
      description: 'Step outside to absorb natural sunlight and stretch legs.',
    ),
    SelfCareActivity(
      id: '4',
      title: 'Evening Gratitude Journal',
      category: 'Reflection',
      durationMinutes: 5,
      isCompleted: false,
      description: 'Write down 3 tiny moments today that brought you ease.',
    ),
    SelfCareActivity(
      id: '5',
      title: 'Screen-Free Wind Down',
      category: 'Rest',
      durationMinutes: 30,
      isCompleted: false,
      description: 'Put your phone on silent mode 30 minutes before sleep.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final completedCount = _activities.where((a) => a.isCompleted).length;
    final progress = _activities.isEmpty ? 0.0 : completedCount / _activities.length;

    return Scaffold(
      appBar: AppBar(title: const Text('Daily Self-Care')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Progress Header Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppTheme.lavenderLight,
                borderRadius: BorderRadius.circular(22),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Today's Progress',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                      ),
                      Text(
                        '$completedCount of ${_activities.length} Completed',
                        style: const TextStyle(fontWeight: FontWeight.w600, color: AppTheme.lavenderPrimary),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: LinearProgressIndicator(
                      value: progress,
                      minHeight: 8,
                      backgroundColor: Colors.white,
                      valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.lavenderPrimary),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    progress == 1.0
                        ? 'Wonderful! You gave yourself mindful kindness today.'
                        : 'Take each step gently at your own pace without pressure.',
                    style: const TextStyle(fontSize: 12.5, color: AppTheme.textMuted),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            const Text('Gentle Daily Intentions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),

            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _activities.length,
              itemBuilder: (context, i) {
                final item = _activities[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: CheckboxListTile(
                    value: item.isCompleted,
                    activeColor: AppTheme.lavenderPrimary,
                    title: Text(
                      item.title,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 14.5,
                        decoration: item.isCompleted ? TextDecoration.lineThrough : null,
                        color: item.isCompleted ? AppTheme.textMuted : AppTheme.textDark,
                      ),
                    ),
                    subtitle: Text(
                      '${item.durationMinutes} min • ${item.description}',
                      style: const TextStyle(fontSize: 12),
                    ),
                    onChanged: (val) {
                      setState(() {
                        item.isCompleted = val ?? false;
                      });
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
