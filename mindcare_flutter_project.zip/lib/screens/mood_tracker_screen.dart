import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/mood_entry.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';
import '../widgets/mood_chart_widget.dart';

class MoodTrackerScreen extends StatefulWidget {
  const MoodTrackerScreen({super.key});

  @override
  State<MoodTrackerScreen> createState() => _MoodTrackerScreenState();
}

class _MoodTrackerScreenState extends State<MoodTrackerScreen> {
  List<MoodEntry> _entries = [];
  String _selectedMood = 'calm';
  final TextEditingController _notesController = TextEditingController();

  final Map<String, Map<String, dynamic>> _moodTypes = {
    'happy': {'label': 'Happy & Joyful', 'icon': Icons.sentiment_very_satisfied_rounded, 'color': Color(0xFF48BB78)},
    'calm': {'label': 'Calm & Grounded', 'icon': Icons.sentiment_satisfied_alt_rounded, 'color': Color(0xFF8C7AE6)},
    'okay': {'label': 'Okay / Neutral', 'icon': Icons.sentiment_neutral_rounded, 'color': Color(0xFF4A90E2)},
    'anxious': {'label': 'Anxious / Restless', 'icon': Icons.sentiment_dissatisfied_rounded, 'color': Color(0xFFED8936)},
    'sad': {'label': 'Sad / Heavy', 'icon': Icons.sentiment_very_dissatisfied_rounded, 'color': Color(0xFFE53E3E)},
  };

  @override
  void initState() {
    super.initState();
    _loadEntries();
  }

  Future<void> _loadEntries() async {
    final loaded = await StorageService.loadMoodEntries();
    setState(() => _entries = loaded);
  }

  void _saveEntry() async {
    final meta = _moodTypes[_selectedMood]!;
    final newEntry = MoodEntry(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      mood: _selectedMood,
      label: meta['label'] as String,
      intensity: _getIntensityValue(_selectedMood),
      tags: ['Daily Check-in'],
      notes: _notesController.text.trim(),
      timestamp: DateTime.now(),
    );

    final updated = [_newEntry, ..._entries];
    await StorageService.saveMoodEntries(updated);
    setState(() {
      _entries = updated;
      _notesController.clear();
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mood recorded successfully.')),
      );
    }
  }

  int _getIntensityValue(String mood) {
    switch (mood) {
      case 'happy': return 5;
      case 'calm': return 4;
      case 'okay': return 3;
      case 'anxious': return 2;
      case 'sad': return 1;
      default: return 3;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mood Tracker')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'How are you feeling right now?',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 14),

            // 5 Mood Selector Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: _moodTypes.entries.map((entry) {
                final isSelected = entry.key == _selectedMood;
                final color = entry.value['color'] as Color;
                final icon = entry.value['icon'] as IconData;

                return GestureDetector(
                  onTap: () => setState(() => _selectedMood = entry.key),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isSelected ? color.withOpacity(0.18) : Colors.white,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: isSelected ? color : Colors.black.withOpacity(0.08),
                            width: isSelected ? 2 : 1,
                          ),
                        ),
                        child: Icon(icon, color: color, size: 30),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        entry.key[0].toUpperCase() + entry.key.substring(1),
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: isSelected ? FontWeight.w700 : FontWeight.w400,
                          color: isSelected ? color : AppTheme.textMuted,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 18),

            // Optional Reflection Notes
            TextField(
              controller: _notesController,
              decoration: const InputDecoration(
                hintText: 'Add an optional note (e.g. took a walk, studied for exam)...',
                contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _saveEntry,
                child: const Text('Log Today's Mood'),
              ),
            ),
            const SizedBox(height: 24),

            // Mood History Chart
            const Text(
              '7-Day Mood Trend',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 10),
            MoodChartWidget(entries: _entries),
            const SizedBox(height: 24),

            // Past Entries List
            const Text(
              'Past Reflections',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 10),
            if (_entries.isEmpty)
              const Center(child: Text('No mood entries recorded yet.'))
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _entries.length,
                itemBuilder: (context, i) {
                  final e = _entries[i];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      leading: Icon(
                        _moodTypes[e.mood]?['icon'] as IconData? ?? Icons.sentiment_satisfied,
                        color: _moodTypes[e.mood]?['color'] as Color? ?? AppTheme.lavenderPrimary,
                      ),
                      title: Text(e.label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                      subtitle: Text(
                        e.notes.isNotEmpty ? e.notes : 'No extra notes provided',
                        style: const TextStyle(fontSize: 12),
                      ),
                      trailing: Text(
                        DateFormat('MMM d').format(e.timestamp),
                        style: const TextStyle(fontSize: 11, color: AppTheme.textMuted),
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}
