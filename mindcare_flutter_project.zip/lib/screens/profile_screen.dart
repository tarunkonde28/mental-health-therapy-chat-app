import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';
import '../widgets/emergency_help_sheet.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  bool _dailyReminder = true;
  bool _soundEnabled = true;

  void _clearLocalData() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear Locally Stored Mood Data?'),
        content: const Text('This will delete all offline mood entries stored on this device. This action cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Clear Data', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await StorageService.clearAllMoodData();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Local mood history cleared.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile & Preferences')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          children: [
            // User Avatar & Name
            Center(
              child: Column(
                children: const [
                  CircleAvatar(
                    radius: 44,
                    backgroundImage: NetworkImage('https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=160&auto=format&fit=crop&q=80'),
                  ),
                  SizedBox(height: 12),
                  Text('Alex Rivera', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  Text('alex.rivera@college.edu', style: TextStyle(fontSize: 13, color: AppTheme.textMuted)),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Preferences
            Card(
              child: Column(
                children: [
                  SwitchListTile(
                    title: const Text('Daily Wellness Reminder', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                    subtitle: const Text('Gentle notification at 8:30 PM', style: TextStyle(fontSize: 12)),
                    value: _dailyReminder,
                    activeColor: AppTheme.lavenderPrimary,
                    onChanged: (val) => setState(() => _dailyReminder = val),
                  ),
                  const Divider(height: 1),
                  SwitchListTile(
                    title: const Text('Haptic / Audio Guidance', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                    subtitle: const Text('Subtle cues during breathing exercises', style: TextStyle(fontSize: 12)),
                    value: _soundEnabled,
                    activeColor: AppTheme.lavenderPrimary,
                    onChanged: (val) => setState(() => _soundEnabled = val),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Emergency Resources Button
            Card(
              child: ListTile(
                leading: const Icon(Icons.health_and_safety_rounded, color: Color(0xFFC53030)),
                title: const Text('Crisis & Emergency Resources', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                subtitle: const Text('Access 24/7 free helplines (988, Tele-MANAS)', style: TextStyle(fontSize: 12)),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () {
                  showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    backgroundColor: Colors.transparent,
                    builder: (ctx) => const EmergencyHelpSheet(),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),

            // Privacy & Data management
            Card(
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.delete_outline_rounded, color: Colors.red),
                    title: const Text('Clear Stored Mood Entries', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600, fontSize: 14)),
                    subtitle: const Text('Reset device storage cache', style: TextStyle(fontSize: 12)),
                    onTap: _clearLocalData,
                  ),
                  const Divider(height: 1),
                  ListTile(
                    leading: const Icon(Icons.logout_rounded, color: AppTheme.textMuted),
                    title: const Text('Sign Out', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                    onTap: () => Navigator.pushReplacementNamed(context, '/welcome'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
