import 'dart:async';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class BreathingScreen extends StatefulWidget {
  const BreathingScreen({super.key});

  @override
  State<BreathingScreen> createState() => _BreathingScreenState();
}

class _BreathingScreenState extends State<BreathingScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  Timer? _phaseTimer;
  bool _isRunning = false;

  int _currentPhaseIndex = 0;
  int _secondsLeft = 4;
  int _cyclesCompleted = 0;

  final List<String> _phases = ['Inhale through nose', 'Hold breath gently', 'Exhale slowly', 'Rest & Pause'];
  final List<int> _durations = [4, 4, 4, 4];

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    );
  }

  void _startBreathing() {
    setState(() {
      _isRunning = true;
      _currentPhaseIndex = 0;
      _secondsLeft = _durations[0];
    });
    _animController.forward(from: 0.0);
    _tick();
  }

  void _tick() {
    _phaseTimer?.cancel();
    _phaseTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!_isRunning) {
        timer.cancel();
        return;
      }
      setState(() {
        if (_secondsLeft > 1) {
          _secondsLeft--;
        } else {
          _currentPhaseIndex = (_currentPhaseIndex + 1) % _phases.length;
          _secondsLeft = _durations[_currentPhaseIndex];
          if (_currentPhaseIndex == 0) {
            _cyclesCompleted++;
            _animController.forward(from: 0.0);
          } else if (_currentPhaseIndex == 2) {
            _animController.reverse(from: 1.0);
          }
        }
      });
    });
  }

  void _pauseBreathing() {
    setState(() => _isRunning = false);
    _phaseTimer?.cancel();
    _animController.stop();
  }

  void _resetBreathing() {
    setState(() {
      _isRunning = false;
      _currentPhaseIndex = 0;
      _secondsLeft = 4;
      _cyclesCompleted = 0;
    });
    _phaseTimer?.cancel();
    _animController.reset();
  }

  @override
  void dispose() {
    _animController.dispose();
    _phaseTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Guided Breathing')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            children: [
              const Text(
                'Box Breathing (4-4-4-4)',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 6),
              const Text(
                'A gentle somatic exercise to stimulate the vagus nerve and slow racing thoughts.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13.5, color: AppTheme.textMuted),
              ),
              const Spacer(),

              // Animated Breathing Sphere
              AnimatedBuilder(
                animation: _animController,
                builder: (context, child) {
                  final scale = 0.8 + (_animController.value * 0.4);
                  return Transform.scale(
                    scale: _isRunning ? scale : 0.85,
                    child: Container(
                      width: 220,
                      height: 220,
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          colors: [
                            AppTheme.lavenderPrimary.withOpacity(0.85),
                            AppTheme.accentBlue.withOpacity(0.4),
                          ],
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.lavenderPrimary.withOpacity(0.3),
                            blurRadius: 36,
                            spreadRadius: 8,
                          ),
                        ],
                      ),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              '$_secondsLeft',
                              style: const TextStyle(
                                fontSize: 48,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                            Text(
                              _phases[_currentPhaseIndex],
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: Colors.white70,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
              const Spacer(),

              Text(
                'Completed Cycles: $_cyclesCompleted',
                style: const TextStyle(fontWeight: FontWeight.w600, color: AppTheme.textMuted),
              ),
              const SizedBox(height: 20),

              // Control Buttons
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  OutlinedButton.icon(
                    onPressed: _resetBreathing,
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Reset'),
                  ),
                  const SizedBox(width: 16),
                  ElevatedButton.icon(
                    onPressed: _isRunning ? _pauseBreathing : _startBreathing,
                    icon: Icon(_isRunning ? Icons.pause_rounded : Icons.play_arrow_rounded),
                    label: Text(_isRunning ? 'Pause' : 'Start'),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Safety disclaimer
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.lavenderLight,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Text(
                  'Safety Note: Breathe gently without straining. If you feel lightheaded, stop immediately and return to your natural breathing.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11.5, color: AppTheme.textMuted),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
