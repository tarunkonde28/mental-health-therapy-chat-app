import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/chat_message.dart';
import '../theme/app_theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  bool _isTyping = false;

  final List<ChatMessage> _messages = [
    ChatMessage(
      id: 'm1',
      isFromUser: false,
      therapistName: 'Dr. Sarah Jenkins',
      text: 'Hello Alex! I’m glad you reached out today. Remember that whatever you are carrying, this is a safe, confidential space. How has your mental energy been feeling today?',
      timestamp: DateTime.now().subtract(const Duration(minutes: 10)),
    ),
  ];

  final List<String> _quickPrompts = [
    'I’m feeling anxious about exams',
    'Can we try a breathing technique?',
    'I have trouble sleeping peacefully',
  ];

  void _sendMessage(String text) {
    if (text.trim().isEmpty) return;

    final userMsg = ChatMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      isFromUser: true,
      therapistName: 'You',
      text: text.trim(),
      timestamp: DateTime.now(),
    );

    setState(() {
      _messages.add(userMsg);
      _controller.clear();
      _isTyping = true;
    });

    _scrollToBottom();

    // Simulated empathetic clinical response
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (!mounted) return;
      String reply = "Thank you for sharing that with me. Acknowledging how you feel without self-judgment is the first powerful step. What physical sensations are accompanying this thought right now?";
      if (text.toLowerCase().contains('exam') || text.toLowerCase().contains('anxious')) {
        reply = "Exam and academic stress can feel intense. Let's remember: your worth as a person is never defined by a single exam score. Would you like to practice our 4-second box breathing together?";
      } else if (text.toLowerCase().contains('sleep')) {
        reply = "Racing thoughts at night are common when the brain hasn't had wind-down time. Let's practice a grounding technique: 5 things you can see, 4 things you can touch.";
      }

      final botMsg = ChatMessage(
        id: (DateTime.now().millisecondsSinceEpoch + 1).toString(),
        isFromUser: false,
        therapistName: 'Dr. Sarah Jenkins',
        text: reply,
        timestamp: DateTime.now(),
      );

      setState(() {
        _messages.add(botMsg);
        _isTyping = false;
      });
      _scrollToBottom();
    });
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          children: const [
            Text('Therapy Chat (Dr. Sarah)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            Text('Demo Clinical AI Simulation', style: TextStyle(fontSize: 11, color: AppTheme.mintGreen)),
          ],
        ),
      ),
      body: Column(
        children: [
          // Demo Banner
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
            color: AppTheme.lavenderLight,
            child: const Text(
              'Demo session for lab evaluation. In emergencies, call 988 or local crisis hotlines.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 11, color: AppTheme.lavenderPrimary),
            ),
          ),

          // Message Bubbles
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final msg = _messages[index];
                return _buildChatBubble(msg);
              },
            ),
          ),

          if (_isTyping)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              child: Row(
                children: const [
                  SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.lavenderPrimary),
                  ),
                  SizedBox(width: 8),
                  Text('Dr. Sarah is typing...', style: TextStyle(fontSize: 12, color: AppTheme.textMuted)),
                ],
              ),
            ),

          // Quick Prompt suggestions
          SizedBox(
            height: 38,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: _quickPrompts.length,
              itemBuilder: (context, i) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ActionChip(
                    label: Text(_quickPrompts[i], style: const TextStyle(fontSize: 11)),
                    onPressed: () => _sendMessage(_quickPrompts[i]),
                    backgroundColor: Colors.white,
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 6),

          // Message Input Field
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: Colors.black.withOpacity(0.06))),
            ),
            child: SafeArea(
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: const InputDecoration(
                        hintText: 'Type your thoughts here...',
                        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      ),
                      onSubmitted: _sendMessage,
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: () => _sendMessage(_controller.text),
                    icon: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: const BoxDecoration(
                        color: AppTheme.lavenderPrimary,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatBubble(ChatMessage msg) {
    final isMe = msg.isFromUser;
    final timeStr = DateFormat('hh:mm a').format(msg.timestamp);

    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: isMe ? AppTheme.lavenderPrimary : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(18),
            topRight: const Radius.circular(18),
            bottomLeft: Radius.circular(isMe ? 18 : 4),
            bottomRight: Radius.circular(isMe ? 4 : 18),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Text(
              msg.text,
              style: TextStyle(
                color: isMe ? Colors.white : AppTheme.textDark,
                fontSize: 14.5,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              timeStr,
              style: TextStyle(
                color: isMe ? Colors.white70 : AppTheme.textMuted,
                fontSize: 10.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
