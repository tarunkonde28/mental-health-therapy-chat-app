import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/emergency_help_sheet.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF9F9FD),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header Row: Greeting & Crisis Shortcut
              Row(
                mainAxisAlignment: MainAxisAlignment.between,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text(
                        'Good Morning, Alex',
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textDark,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'How are you feeling right now?',
                        style: TextStyle(fontSize: 14, color: AppTheme.textMuted),
                      ),
                    ],
                  ),
                  IconButton(
                    onPressed: () {
                      showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        backgroundColor: Colors.transparent,
                        builder: (ctx) => const EmergencyHelpSheet(),
                      );
                    },
                    icon: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.peachWarm.withOpacity(0.5),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.health_and_safety_rounded, color: Color(0xFFC53030), size: 22),
                    ),
                    tooltip: 'Emergency & Crisis Helplines',
                  ),
                ],
              ),
              const SizedBox(height: 20),

              // Daily Affirmation Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF8C7AE6), Color(0xFF6C5CE7)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(22),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.lavenderPrimary.withOpacity(0.25),
                      blurRadius: 18,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: const [
                        Icon(Icons.auto_awesome, color: Colors.amberAccent, size: 18),
                        SizedBox(width: 8),
                        Text(
                          'DAILY THOUGHT',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1.2,
                            color: Colors.white70,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      '“Feelings are something you have; not something you are. Be patient with your mind.”',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontStyle: FontStyle.italic,
                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Quick Access Grid
              const Text(
                'Wellness Tools',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 12),
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.35,
                children: [
                  _buildToolCard(
                    context,
                    title: 'Guided Breathing',
                    subtitle: 'Box 4-4-4-4 rhythm',
                    icon: Icons.air_rounded,
                    color: AppTheme.lightBlue,
                    iconColor: AppTheme.accentBlue,
                    onTap: () => Navigator.pushNamed(context, '/breathing'),
                  ),
                  _buildToolCard(
                    context,
                    title: 'Self-Care Checklist',
                    subtitle: 'Daily gentle goals',
                    icon: Icons.check_circle_outline_rounded,
                    color: AppTheme.mintLight,
                    iconColor: AppTheme.mintGreen,
                    onTap: () => Navigator.pushNamed(context, '/self-care'),
                  ),
                  _buildToolCard(
                    context,
                    title: 'Therapy Chat',
                    subtitle: 'Supportive AI demo',
                    icon: Icons.forum_rounded,
                    color: AppTheme.lavenderLight,
                    iconColor: AppTheme.lavenderPrimary,
                    onTap: () {
                      // Handled via bottom bar or tab index
                    },
                  ),
                  _buildToolCard(
                    context,
                    title: 'Mood History',
                    subtitle: 'Track your rhythms',
                    icon: Icons.insights_rounded,
                    color: const Color(0xFFFFF5F5),
                    iconColor: const Color(0xFFE53E3E),
                    onTap: () {
                      // Handled via bottom bar
                    },
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Upcoming Demo Appointment
              const Text(
                'Upcoming Consultation',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 10),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: AppTheme.lavenderLight,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(Icons.video_camera_front_rounded, color: AppTheme.lavenderPrimary),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text(
                              'Dr. Sarah Jenkins',
                              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                            ),
                            SizedBox(height: 2),
                            Text(
                              'Today at 3:30 PM • 50 min session',
                              style: TextStyle(fontSize: 13, color: AppTheme.textMuted),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppTheme.mintLight,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Text(
                          'Confirmed',
                          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppTheme.mintGreen),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildToolCard(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required Color iconColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(20),
          border: Border.Border.all(color: Colors.black.withOpacity(0.03)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(icon, color: iconColor, size: 28),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 11.5, color: AppTheme.textMuted),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
