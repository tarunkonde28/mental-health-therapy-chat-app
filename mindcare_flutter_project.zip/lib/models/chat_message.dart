class ChatMessage {
  final String id;
  final bool isFromUser;
  final String therapistName;
  final String text;
  final DateTime timestamp;

  ChatMessage({
    required this.id,
    required this.isFromUser,
    required this.therapistName,
    required this.text,
    required this.timestamp,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'isFromUser': isFromUser,
    'therapistName': therapistName,
    'text': text,
    'timestamp': timestamp.toIso8601String(),
  };

  factory ChatMessage.fromJson(Map<String, dynamic> json) => ChatMessage(
    id: json['id'] as String,
    isFromUser: json['isFromUser'] as bool,
    therapistName: json['therapistName'] as String,
    text: json['text'] as String,
    timestamp: DateTime.parse(json['timestamp'] as String),
  );
}
