class SelfCareActivity {
  final String id;
  final String title;
  final String category;
  final int durationMinutes;
  bool isCompleted;
  final String description;

  SelfCareActivity({
    required this.id,
    required this.title,
    required this.category,
    required this.durationMinutes,
    this.isCompleted = false,
    required this.description,
  });
}
